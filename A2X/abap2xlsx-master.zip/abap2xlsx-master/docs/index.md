This community project allows you to generate Professional Excel spreadsheets directly from ABAP.

**Resources**

* Installation guide
   * [abapGit](abapGit-installation) (Preferred)
   * [SAPLink](SAPLink-installation) (obsolete)
* [F.A.Q.](FAQ)
* [abap2xlsx Calender Gallery](abap2xlsx-Calender-Gallery)
