﻿To build and run you need OpenXMl SDK installed.
It can be downloaded from http://www.microsoft.com/downloads/details.aspx?FamilyID=c6e744e5-36e9-45f5-8d8c-331df206e0d0&displaylang=en